package com.example.detectionDiabete.Repository;

import com.example.detectionDiabete.entities.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {
  // Optionnel : méthode pour trouver un admin par son email
  Optional<Admin> findByEmail(String email);
}
