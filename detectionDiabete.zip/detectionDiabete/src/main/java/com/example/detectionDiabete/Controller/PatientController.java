package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.dto.PatientDTO;
import com.example.detectionDiabete.entities.Patient;
import com.example.detectionDiabete.entities.RendezVous;
import com.example.detectionDiabete.entities.ResultatPatient;
import com.example.detectionDiabete.services.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    // Récupérer le dossier médical d'un patient
    @GetMapping("/{id}")
    public ResponseEntity<Patient> recupererDossierMedical(@PathVariable Long id) {
        Patient patient = patientService.recupererDossierMedical(id);
        return ResponseEntity.ok(patient);
    }

    // Demander un rendez-vous
    @PostMapping("/{idPatient}/rendezvous/{idMedecin}")
    public ResponseEntity<RendezVous> demanderRendezVous(
            @PathVariable Long idPatient,
            @PathVariable Long idMedecin,
            @RequestBody LocalDateTime date) {
        RendezVous rendezVous = patientService.demanderRendezVous(idPatient, idMedecin, date);
        return ResponseEntity.ok(rendezVous);
    }

    // Consulter le diagnostic
    @GetMapping("/{id}/diagnostic")
    public ResponseEntity<ResultatPatient> consulterDiagnostic(@PathVariable Long id) {
        ResultatPatient resultat = (ResultatPatient) patientService.consulterDiagnostic(id);
        return ResponseEntity.ok(resultat);
    }
}
