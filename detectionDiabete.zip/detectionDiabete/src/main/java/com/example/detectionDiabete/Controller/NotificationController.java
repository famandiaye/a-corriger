package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.entities.Notification;
import com.example.detectionDiabete.services.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    // Créer une nouvelle notification
    @PostMapping
    public ResponseEntity<Notification> createNotification(@RequestBody Notification notification) {
        Notification createdNotification = notificationService.creerNotification(notification);
        return ResponseEntity.ok(createdNotification);
    }

    // Récupérer toutes les notifications pour un médecin
    @GetMapping("/medecin/{idMedecin}")
    public ResponseEntity<List<Notification>> getNotificationsForMedecin(@PathVariable Long idMedecin) {
        List<Notification> notifications = notificationService.recupererNotificationsPourMedecin(idMedecin);
        return ResponseEntity.ok(notifications);
    }

    // Récupérer toutes les notifications pour un patient
    @GetMapping("/patient/{idPatient}")
    public ResponseEntity<List<Notification>> getNotificationsForPatient(@PathVariable Long idPatient) {
        List<Notification> notifications = notificationService.recupererNotificationsPourPatient(idPatient);
        return ResponseEntity.ok(notifications);
    }
}
