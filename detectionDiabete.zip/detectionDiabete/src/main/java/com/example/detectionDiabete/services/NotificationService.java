package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.Notification;
import com.example.detectionDiabete.Repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    // Créer une nouvelle notification
    public Notification creerNotification(Notification notification) {
        return notificationRepository.save(notification);
    }

    // Récupérer toutes les notifications pour un médecin
    public List<Notification> recupererNotificationsPourMedecin(Long idMedecin) {
        return notificationRepository.findByIdMedecin(idMedecin);
    }

    // Récupérer toutes les notifications pour un patient
    public List<Notification> recupererNotificationsPourPatient(Long idPatient) {
        return notificationRepository.findByIdPatient(idPatient);
    }
}
