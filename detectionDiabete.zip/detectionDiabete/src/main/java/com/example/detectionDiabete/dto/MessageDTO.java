package com.example.detectionDiabete.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor // Constructeur sans arguments
@AllArgsConstructor // Constructeur avec tous les paramètres
public class MessageDTO {
    private Long id; // Identifiant unique du message
    private Long idMedecin; // Identifiant du médecin
    private Long idPatient; // Identifiant du patient
    private String contenu; // Contenu du message
    private LocalDateTime dateEnvoi; // Date et heure de l'envoi du message
}
