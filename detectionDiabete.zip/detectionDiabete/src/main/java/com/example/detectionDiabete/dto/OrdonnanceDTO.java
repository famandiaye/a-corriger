package com.example.detectionDiabete.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor // Génère un constructeur sans arguments
@AllArgsConstructor // Génère un constructeur avec tous les paramètres
public class OrdonnanceDTO {
    private Long id;
    private String nom;
    private String description;
    private String dosage;
    private Long idPatient; // ID du patient
    private Long idMedecin; // ID du médecin
}
