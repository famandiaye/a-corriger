package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.entities.Medecin;
import com.example.detectionDiabete.services.MedecinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medecins")
public class MedecinController {

    @Autowired
    private MedecinService medecinService;

    // Créer un nouveau médecin
    @PostMapping
    public ResponseEntity<Medecin> ajouterMedecin(@RequestBody Medecin medecin) {
        Medecin savedMedecin = medecinService.modifierMedecin(null, medecin); // Si ID nul, cela signifie création
        return ResponseEntity.ok(savedMedecin);
    }

    // Récupérer tous les médecins
    @GetMapping
    public ResponseEntity<List<Medecin>> recupererTousLesMedecins() {
        // Ajoutez une méthode findAll dans le MedecinService si nécessaire
        List<Medecin> medecins = medecinService.findAll(); // Assurez-vous que cette méthode existe
        return ResponseEntity.ok(medecins);
    }

    // Récupérer un médecin par ID
    @GetMapping("/{id}")
    public ResponseEntity<Medecin> recupererMedecinParId(@PathVariable Long id) {
        Medecin medecin = medecinService.getMedecinById(id);
        return ResponseEntity.ok(medecin);
    }

    // Modifier un médecin
    @PutMapping("/{id}")
    public ResponseEntity<Medecin> modifierMedecin(@PathVariable Long id, @RequestBody Medecin medecinDetails) {
        Medecin updatedMedecin = medecinService.modifierMedecin(id, medecinDetails);
        return ResponseEntity.ok(updatedMedecin);
    }

    // Supprimer un médecin
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerMedecin(@PathVariable Long id) {
        medecinService.supprimerMedecin(id);
        return ResponseEntity.noContent().build();
    }
}
