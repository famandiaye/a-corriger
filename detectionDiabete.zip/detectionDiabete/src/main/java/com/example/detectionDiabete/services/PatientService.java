package com.example.detectionDiabete.services;

import com.example.detectionDiabete.entities.Patient;
import com.example.detectionDiabete.entities.RendezVous;
import com.example.detectionDiabete.entities.ResultatPatient;
import com.example.detectionDiabete.Repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private RendezVousService rendezVousService;

    @Autowired
    private ResultatPatientService resultatPatientService;

    // Récupérer le dossier médical d'un patient
    public Patient recupererDossierMedical(Long idPatient) {
        return patientRepository.findById(idPatient)
                .orElseThrow(() -> new RuntimeException("Patient non trouvé avec ID: " + idPatient));
    }

    // Demander à parler à un médecin (prendre rendez-vous)
    public RendezVous demanderRendezVous(Long idPatient, Long idMedecin, LocalDateTime date) {
        return rendezVousService.proposerRendezVous(idMedecin, idPatient, date);
    }

    // Consulter le diagnostic
    public List<ResultatPatient> consulterDiagnostic(Long idPatient) {
        List<ResultatPatient> resultats = resultatPatientService.recupererResultats(idPatient);
        if (resultats.isEmpty()) {
            throw new RuntimeException("Aucun diagnostic trouvé pour le patient avec ID: " + idPatient);
        }
        return resultats;
    }

    // Méthode pour trouver un patient par son ID
    public Patient findPatientById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient non trouvé avec ID: " + id));
    }
}
