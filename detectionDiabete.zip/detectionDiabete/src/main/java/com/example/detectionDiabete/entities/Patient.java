package com.example.detectionDiabete.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
public class Patient extends Utilisateurs {

    @OneToMany(mappedBy = "patient")
    private List<Ordonnance> ordonnances; // Liste des ordonnances associées à ce patient

}
