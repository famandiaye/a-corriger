package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.dto.MessageDTO;
import com.example.detectionDiabete.entities.Message; // Assurez-vous que cette entité existe
import com.example.detectionDiabete.services.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private MessageService messageService;

    // Envoyer un message
    @PostMapping("/envoyer")
    public ResponseEntity<MessageDTO> envoyerMessage(@RequestBody MessageDTO messageDTO) {
        // Appel du service pour envoyer le message
        messageService.envoyerMessage(messageDTO.getIdMedecin(), messageDTO.getIdPatient(), messageDTO.getContenu());

        // Ajout de la date d'envoi au DTO
        messageDTO.setDateEnvoi(LocalDateTime.now());

        return ResponseEntity.ok(messageDTO);
    }

    // Récupérer les messages échangés entre un médecin et un patient
    @GetMapping("/medecin/{idMedecin}/patient/{idPatient}")
    public ResponseEntity<List<MessageDTO>> recupererMessages(@PathVariable Long idMedecin, @PathVariable Long idPatient) {
        List<Message> messages = messageService.recupererMessages(idMedecin, idPatient);
        List<MessageDTO> messageDTOs = messages.stream()
                .map(message -> new MessageDTO(
                        message.getId(),
                        message.getIdMedecin(),
                        message.getIdPatient(),
                        message.getContenu(),
                        message.getDateEnvoi() // Assurez-vous que cette propriété existe dans votre entité
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(messageDTOs);
    }

    // Récupérer tous les messages pour un médecin spécifique
    @GetMapping("/medecin/{idMedecin}")
    public ResponseEntity<List<MessageDTO>> recupererMessagesPourMedecin(@PathVariable Long idMedecin) {
        List<Message> messages = messageService.recupererMessagesPourMedecin(idMedecin);
        List<MessageDTO> messageDTOs = messages.stream()
                .map(message -> new MessageDTO(
                        message.getId(),
                        message.getIdMedecin(),
                        message.getIdPatient(),
                        message.getContenu(),
                        message.getDateEnvoi() // Assurez-vous que cette propriété existe dans votre entité
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(messageDTOs);
    }

    // Récupérer tous les messages pour un patient spécifique
    @GetMapping("/patient/{idPatient}")
    public ResponseEntity<List<MessageDTO>> recupererMessagesPourPatient(@PathVariable Long idPatient) {
        List<Message> messages = messageService.recupererMessagesPourPatient(idPatient);
        List<MessageDTO> messageDTOs = messages.stream()
                .map(message -> new MessageDTO(
                        message.getId(),
                        message.getIdMedecin(),
                        message.getIdPatient(),
                        message.getContenu(),
                        message.getDateEnvoi() // Assurez-vous que cette propriété existe dans votre entité
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(messageDTOs);
    }
}
