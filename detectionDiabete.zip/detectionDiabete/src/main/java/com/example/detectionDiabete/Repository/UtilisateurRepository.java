package com.example.detectionDiabete.Repository;

import com.example.detectionDiabete.entities.Utilisateurs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UtilisateurRepository extends JpaRepository<Utilisateurs, Long> {

    // Méthode pour trouver un utilisateur par son email
    Optional<Utilisateurs> findByEmail(String email);

    // Méthode pour supprimer un utilisateur par son ID
    void deleteById(Long id);
}
