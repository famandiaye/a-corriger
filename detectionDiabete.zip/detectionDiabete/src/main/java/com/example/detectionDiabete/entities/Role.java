package com.example.detectionDiabete.entities;

public enum Role {
    MEDECIN,
    PATIENT,
    ADMIN
}
