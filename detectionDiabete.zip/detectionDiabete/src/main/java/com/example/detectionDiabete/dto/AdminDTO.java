package com.example.detectionDiabete.dto;


import lombok.Data;

@Data
public class AdminDTO {
    private Long id;
    private String nom;
    private String email;
    private String role;

}
