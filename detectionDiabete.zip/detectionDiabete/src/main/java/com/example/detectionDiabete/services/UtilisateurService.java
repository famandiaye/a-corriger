package com.example.detectionDiabete.services;

import com.example.detectionDiabete.dto.UtilisateursDTO;
import com.example.detectionDiabete.dto.LoginRequest;
import com.example.detectionDiabete.entities.Role;
import com.example.detectionDiabete.entities.Utilisateurs;
import com.example.detectionDiabete.Repository.UtilisateurRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class UtilisateurService {

    @Autowired
    private UtilisateurRepository utilisateursRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private final String secretKey = "r30f1kZQPgPyza6UlNZYj8/1Ak5oMhvhE8J+FvvnM90=";

    /**
     * Inscription d'un nouvel utilisateur.
     *
     * @param userDto DTO contenant les informations de l'utilisateur.
     * @throws RuntimeException si l'email est déjà utilisé.
     */
    @Transactional
    public void register(UtilisateursDTO userDto) {
        if (trouverUtilisateurParEmail(userDto.getEmail()).isPresent()) {
            throw new RuntimeException("L'email est déjà utilisé.");
        }

        Utilisateurs nouvelUtilisateur = new Utilisateurs();
        nouvelUtilisateur.setNom(userDto.getNom());
        nouvelUtilisateur.setPrenom(userDto.getPrenom());
        nouvelUtilisateur.setEmail(userDto.getEmail());
        nouvelUtilisateur.setMotDePasse(passwordEncoder.encode(userDto.getMotDePasse()));
        nouvelUtilisateur.setTelephone(userDto.getTelephone());
        nouvelUtilisateur.setDateDeNaissance(userDto.getDateDeNaissance());
        nouvelUtilisateur.setRole(Role.valueOf(userDto.getRole()));

        utilisateursRepository.save(nouvelUtilisateur);
    }

    /**
     * Connexion d'un utilisateur et génération d'un JWT.
     *
     * @param loginRequest Requête contenant les informations de connexion.
     * @return Un token JWT pour l'utilisateur connecté.
     * @throws RuntimeException si les identifiants sont invalides.
     */
    public String login(LoginRequest loginRequest) {
        Optional<Utilisateurs> utilisateurTrouve = utilisateursRepository.findByEmail(loginRequest.getEmail());

        if (utilisateurTrouve.isEmpty() || !passwordEncoder.matches(loginRequest.getMotDePasse(), utilisateurTrouve.get().getMotDePasse())) {
            throw new RuntimeException("Identifiants invalides.");
        }

        return generateJwtToken(utilisateurTrouve.get());
    }

    /**
     * Génère un token JWT pour l'utilisateur donné.
     *
     * @param utilisateur L'utilisateur pour lequel générer le token.
     * @return Un token JWT sous forme de chaîne.
     */
    private String generateJwtToken(Utilisateurs utilisateur) {
        Claims claims = Jwts.claims().setSubject(utilisateur.getEmail());
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + 86400000); // 24 heures

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(SignatureAlgorithm.HS512, secretKey)
                .compact();
    }

    /**
     * Modifie les informations d'un utilisateur existant.
     *
     * @param id              L'ID de l'utilisateur à modifier.
     * @param utilisateurDetails DTO contenant les nouvelles informations.
     * @return L'utilisateur modifié.
     * @throws NoSuchElementException si l'utilisateur n'est pas trouvé.
     */
    public Utilisateurs modifierUtilisateur(Long id, Utilisateurs utilisateurDetails) {
        Utilisateurs utilisateur = utilisateursRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Utilisateur non trouvé avec l'ID: " + id));

        utilisateur.setNom(utilisateurDetails.getNom());
        utilisateur.setPrenom(utilisateurDetails.getPrenom());
        utilisateur.setEmail(utilisateurDetails.getEmail());
        if (utilisateurDetails.getMotDePasse() != null) {
            utilisateur.setMotDePasse(passwordEncoder.encode(utilisateurDetails.getMotDePasse()));
        }
        utilisateur.setTelephone(utilisateurDetails.getTelephone());
        utilisateur.setDateDeNaissance(utilisateurDetails.getDateDeNaissance());
        return utilisateursRepository.save(utilisateur);
    }

    /**
     * Supprime un utilisateur par son ID.
     *
     * @param id L'ID de l'utilisateur à supprimer.
     */
    public void supprimerUtilisateur(Long id) {
        utilisateursRepository.deleteById(id);
    }

    /**
     * Recherche un utilisateur par son ID.
     *
     * @param id L'ID de l'utilisateur à rechercher.
     * @return Un Optional contenant l'utilisateur, s'il existe.
     */
    public Optional<Utilisateurs> trouverUtilisateurParId(Long id) {
        return utilisateursRepository.findById(id);
    }

    /**
     * Recherche un utilisateur par son email.
     *
     * @param email L'email de l'utilisateur à rechercher.
     * @return Un Optional contenant l'utilisateur, s'il existe.
     */
    public Optional<Utilisateurs> trouverUtilisateurParEmail(String email) {
        return utilisateursRepository.findByEmail(email);
    }

    /**
     * Recherche un utilisateur par son nom d'utilisateur (email).
     *
     * @param username Le nom d'utilisateur à rechercher.
     * @return Un Optional contenant l'utilisateur, s'il existe.
     */
    public Optional<Utilisateurs> findByUsername(String username) {
        return utilisateursRepository.findByEmail(username);
    }

    /**
     * Récupère un utilisateur par son ID.
     *
     * @param id L'ID de l'utilisateur à récupérer.
     * @return L'utilisateur.
     * @throws NoSuchElementException si l'utilisateur n'est pas trouvé.
     */
    public Utilisateurs getUtilisateurById(Long id) {
        return utilisateursRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Utilisateur non trouvé avec l'ID: " + id));
    }

    /**
     * Récupère tous les utilisateurs.
     *
     * @return Une liste de tous les utilisateurs.
     */
    public List<Utilisateurs> findAllUtilisateurs() {
        return utilisateursRepository.findAll();
    }
}
//