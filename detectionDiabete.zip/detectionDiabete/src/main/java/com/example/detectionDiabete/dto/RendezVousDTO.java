package com.example.detectionDiabete.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data


public class RendezVousDTO {
    private Long id;
    private Long idMedecin;
    private Long idPatient;
    private LocalDateTime dateRendezVous;
    private String statut; // Proposé, Confirmé, Rejeté
}
