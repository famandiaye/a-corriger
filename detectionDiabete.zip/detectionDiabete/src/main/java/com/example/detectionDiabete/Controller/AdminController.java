package com.example.detectionDiabete.Controller;

import com.example.detectionDiabete.entities.Utilisateurs;
import com.example.detectionDiabete.services.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // Créer un nouvel utilisateur
    @PostMapping("/utilisateurs")
    public ResponseEntity<Utilisateurs> creerUtilisateur(@RequestBody Utilisateurs utilisateur) {
        Utilisateurs nouvelUtilisateur = adminService.creerUtilisateur(utilisateur);
        return ResponseEntity.ok(nouvelUtilisateur);
    }

    // Mettre à jour un utilisateur existant
    @PutMapping("/utilisateurs/{id}")
    public ResponseEntity<Utilisateurs> mettreAJourUtilisateur(@PathVariable Long id, @RequestBody Utilisateurs utilisateurDetails) {
        Utilisateurs utilisateurMisAJour = adminService.mettreAJourUtilisateur(id, utilisateurDetails);
        return ResponseEntity.ok(utilisateurMisAJour);
    }

    // Supprimer un utilisateur
    @DeleteMapping("/utilisateurs/{id}")
    public ResponseEntity<Void> supprimerUtilisateur(@PathVariable Long id) {
        adminService.supprimerUtilisateur(id);
        return ResponseEntity.noContent().build();
    }

    // Récupérer tous les utilisateurs
    @GetMapping("/utilisateurs")
    public ResponseEntity<List<Utilisateurs>> recupererTousLesUtilisateurs() {
        List<Utilisateurs> utilisateurs = adminService.recupererTousLesUtilisateurs();
        return ResponseEntity.ok(utilisateurs);
    }

    // Récupérer un utilisateur par ID
    @GetMapping("/utilisateurs/{id}")
    public ResponseEntity<Utilisateurs> recupererUtilisateurParId(@PathVariable Long id) {
        Utilisateurs utilisateur = adminService.recupererUtilisateurParId(id);
        return ResponseEntity.ok(utilisateur);
    }
}
