package com.example.detectionDiabete.Repository;

import com.example.detectionDiabete.entities.ResultatPatient;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ResultatPatientRepository extends JpaRepository<ResultatPatient, Long> {
  List<ResultatPatient> findByIdPatient(Long idPatient);
  List<ResultatPatient> findByIdMedecin(Long idMedecin);
}
