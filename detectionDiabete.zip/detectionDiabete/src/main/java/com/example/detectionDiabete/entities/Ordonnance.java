package com.example.detectionDiabete.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Représente une ordonnance médicale.
 */
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
public class Ordonnance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Le nom du médicament ne peut pas être vide.")
    private String nom; // Nom du médicament

    @NotBlank(message = "La description ne peut pas être vide.")
    private String description; // Description du médicament

    @NotBlank(message = "Le dosage ne peut pas être vide.")
    private String dosage; // Dosage du médicament

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false) // Nom de la colonne pour la clé étrangère
    private Patient patient; // Référence au Patient

    @ManyToOne
    @JoinColumn(name = "medecin_id", nullable = false) // Nom de la colonne pour la clé étrangère
    private Medecin medecin; // Référence au Médecin
}
